package util;

public enum Role {
APPLICANT,
OFFICER,
MANAGER
}
