package util;

public interface FilePath {
	final String filePath = "BTOSystem/src/data/";
	final String loginFilePath=filePath+"LoginInfo.txt";
	final String userDatabaseFilePath=filePath+"UserDatabase.txt";
	final String enquiryDatabaseFilePath=filePath+"EnquiryDatabase.txt";
	final String projectDatabaseFilePath=filePath+"ProjectDatabase.txt";
	final String officerApplicationDatabaseFilePath=filePath+"OfficerApplicationDatabase.txt";
	final String projectApplicationDatabaseFilePath=filePath+"ProjectApplicationDatabase.txt";
	
}
